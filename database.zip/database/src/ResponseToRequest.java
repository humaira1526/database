public class ResponseToRequest 
{
		protected String ClientID;
	 	protected String RequestStatus;
	    protected String InitialQuote;
	    protected String RequestNote;
	  

	 
	    //constructors
	    public ResponseToRequest() {
	    }
	 
	    public ResponseToRequest(String ClientID) 
	    {
	        this.ClientID = ClientID;
	    }
	    
	    /*public users(String ClientID,String RequestStatus, String InitialQuote, String RequestNote, String adress_street_num, String adress_street, String adress_city, String adress_state,String adress_zip_code, String ProxToHouse, String RequestStatus, String RequestNote) 
	    {
	    	this(RequestStatus,InitialQuote,RequestNote, adress_street_num,  adress_street,  adress_city,  adress_state,  adress_zip_code,ProxToHouse, RequestStatus, RequestNote);
	    	this.ClientID = ClientID;
	    }*/
	 
	
	    public ResponseToRequest( String ClientID, String RequestStatus, String InitialQuote, String RequestNote) 
	    {
	    	this.ClientID = ClientID;
	    	this.RequestStatus = RequestStatus;
	    	this.InitialQuote = InitialQuote;
	    	this.RequestNote = RequestNote;
	        
	    }
	    
	   //getter and setter methods
	    public String getClientID() {
	        return ClientID;
	    }
	    public void setClientID(String ClientID) {
	        this.ClientID = ClientID;
	    }
	    
	    public String getRequestStatus() {
	        return RequestStatus;
	    }
	    public void setRequestStatus(String RequestStatus) {
	        this.RequestStatus = RequestStatus;
	    }
	    
	    public String getInitialQuote() {
	        return InitialQuote;
	    }
	    public void setInitialQuote(String InitialQuote) {
	        this.InitialQuote = InitialQuote;
	    }
	    
	    public String getRequestNote() {
	        return RequestNote;
	    }
	    public void setRequestNote(String RequestNote) {
	        this.RequestNote = RequestNote;
	    }
	  
}
	  
	   