public class Bill 
{
		protected String ClientID;
		protected String OrderID;
		private String BillAmount;
	 	protected String Credit_Card;
	    protected String BillStatus;
	  

	 
	    //constructors
	    public Bill() {
	    }
	 
	    public Bill(String ClientID) 
	    {
	        this.ClientID = ClientID;
	    }
	    
	    /*public users(String ClientID,String RequestStatus, String InitialQuote, String BillAmount, String adress_street_num, String adress_street, String adress_city, String adress_state,String adress_zip_code, String ProxToHouse, String RequestStatus, String BillAmount) 
	    {
	    	this(RequestStatus,InitialQuote,BillAmount, adress_street_num,  adress_street,  adress_city,  adress_state,  adress_zip_code,ProxToHouse, RequestStatus, BillAmount);
	    	this.ClientID = ClientID;
	    }*/
	 
	
	    public Bill( String ClientID, String OrderID, String BillAmount,String Credit_Card,String BillStatus) 
	    {
	    	this.ClientID = ClientID;
	    	this.OrderID = OrderID;
	    	//this.InitialQuote = InitialQuote;
	    	this.BillAmount = BillAmount;
	    	this.Credit_Card = Credit_Card;
	    	this.BillStatus = BillStatus;
	        
	    }
	    
	   //getter and setter methods
	    public String getClientID() {
	        return ClientID;
	    }
	    public void setClientID(String ClientID) {
	        this.ClientID = ClientID;
	    }
	    
	    public String getOrderID() {
	        return OrderID;
	    }
	    public void setOrderID(String OrderID) {
	        this.OrderID = OrderID;
	    }
	    
	   
	    
	    public String getBillAmount() {
	        return BillAmount;
	    }
	    public void setBillAmount(String BillAmount) {
	        this.BillAmount = BillAmount;
	    }
	    
	    
	  
	    public String getCredit_Card() {
	        return Credit_Card;
	    }
	    public void setCredit_Card(String Credit_Card) {
	        this.Credit_Card = Credit_Card;
	    }
	    public String getBillStatus() {
	        return BillAmount;
	    }
	    public void setBillStatus(String BillStatus) {
	        this.BillStatus = BillStatus;
	    }
}
	  
	   