public class user 
{
		protected String password;
	 	protected String ClientID;
	    protected String firstName;
	    protected String lastName;
	    protected String adress_street_num;
	    protected String adress_street;
	    protected String adress_city;
	    protected String adress_state;
	    protected String adress_zip_code;
	    protected String _role;
	    protected String credit_card;
	    protected String credit_card2;

	 
	    //constructors
	    public user() {
	    }
	 
	    public user(String ClientID) 
	    {
	        this.ClientID = ClientID;
	    }
	    
	    /*public users(String ClientID,String firstName, String lastName, String password, String adress_street_num, String adress_street, String adress_city, String adress_state,String adress_zip_code, String _role, String credit_card2, String credit_card) 
	    {
	    	this(firstName,lastName,password, adress_street_num,  adress_street,  adress_city,  adress_state,  adress_zip_code,_role, credit_card2, credit_card);
	    	this.ClientID = ClientID;
	    }*/
	 
	
	    public user( String ClientID, String firstName, String lastName, String password, String adress_street_num, String adress_street, String adress_city, String adress_state,String adress_zip_code, String _role, String credit_card, String credit_card2) 
	    {
	    	this.ClientID = ClientID;
	    	this.firstName = firstName;
	    	this.lastName = lastName;
	    	this.password = password;
	        this.adress_street_num = adress_street_num;
	        this.adress_street = adress_street;
	        this.adress_city= adress_city;
	        this.adress_state = adress_state;
	        this.adress_zip_code = adress_zip_code;
	        this._role = _role;
	        this.credit_card = credit_card;
	        this.credit_card2 = credit_card2;
	    }
	    
	   //getter and setter methods
	    public String getEmail() {
	        return ClientID;
	    }
	    public void setEmail(String ClientID) {
	        this.ClientID = ClientID;
	    }
	    
	    public String getFirstName() {
	        return firstName;
	    }
	    public void setFirstName(String firstName) {
	        this.firstName = firstName;
	    }
	    
	    public String getLastName() {
	        return lastName;
	    }
	    public void setLastName(String lastName) {
	        this.lastName = lastName;
	    }
	    
	    public String getPassword() {
	        return password;
	    }
	    public void setPassword(String password) {
	        this.password = password;
	    }
	  
	  
	    public void set_role(String _role) {
	    	this._role = _role;
	    }
	    public String get_role() {
	        return _role;
	    }
	    
	    public void setPhone_Num(String credit_card) {
	    	this.credit_card = credit_card;
	    }
	    public String getcredit_card() {
	        return credit_card;
	    }
	    
	    public void setcredit_card2(String credit_card2) {
	    	this.credit_card2 = credit_card2;
	    }
	    public String getcredit_card2() {
	        return credit_card2;
	    }
	   
	    
	    public String getAdress_street_num() {
	        return adress_street_num;
	    }
	    public void setAdress_street_num(String adress_street_num) {
	        this.adress_street_num = adress_street_num;
	    }
	    public String getAdress_street() {
	        return adress_street;
	    }
	    public void setAdress_street(String adress_street) {
	        this.adress_street = adress_street;
	    }
	    public String getAdress_city() {
	        return adress_city;
	    }
	    public void setAdress_city(String adress_city) {
	        this.adress_city = adress_city;
	    }
	    public String getAdress_state() {
	        return adress_state;
	    }
	    public void setAdress_state(String adress_state) {
	        this.adress_state = adress_state;
	    }
	    public String getAdress_zip_code() {
	        return adress_zip_code;
	    }
	    public void setAdress_zip_code(String adress_zip_code) {
	        this.adress_zip_code = adress_zip_code;
	    }
	    

	}