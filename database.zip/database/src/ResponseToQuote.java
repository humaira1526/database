public class ResponseToQuote 
{
		protected String ClientID;
		protected String OrderID;
	 	protected String RequestStatus;
	    protected String RequestNote;
	  

	 
	    //constructors
	    public ResponseToQuote() {
	    }
	 
	    public ResponseToQuote(String ClientID) 
	    {
	        this.ClientID = ClientID;
	    }
	    
	    /*public users(String ClientID,String RequestStatus, String InitialQuote, String RequestNote, String adress_street_num, String adress_street, String adress_city, String adress_state,String adress_zip_code, String ProxToHouse, String RequestStatus, String RequestNote) 
	    {
	    	this(RequestStatus,InitialQuote,RequestNote, adress_street_num,  adress_street,  adress_city,  adress_state,  adress_zip_code,ProxToHouse, RequestStatus, RequestNote);
	    	this.ClientID = ClientID;
	    }*/
	 
	
	    public ResponseToQuote( String ClientID, String OrderID, String RequestStatus, String RequestNote) 
	    {
	    	this.ClientID = ClientID;
	    	this.RequestStatus = RequestStatus;
	    	this.OrderID = OrderID;
	    	this.RequestNote = RequestNote;
	        
	    }
	    
	   //getter and setter methods
	    public String getClientID() {
	        return ClientID;
	    }
	    public void setClientID(String ClientID) {
	        this.ClientID = ClientID;
	    }
	    
	    public String getOrderID() {
	        return OrderID;
	    }
	    public void setOrderID(String OrderID) {
	        this.OrderID = OrderID;
	    }
	    
	    public String getRequestStatus() {
	        return RequestStatus;
	    }
	    public void setRequestStatus(String RequestStatus) {
	        this.RequestStatus = RequestStatus;
	    }
	    
	   
	    
	    public String getRequestNote() {
	        return RequestNote;
	    }
	    public void setRequestNote(String RequestNote) {
	        this.RequestNote = RequestNote;
	    }
	  
}
	  
	   