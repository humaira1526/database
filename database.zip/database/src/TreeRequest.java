public class TreeRequest 
{
		protected String RequestID;
	 	protected String ClientID;
	    protected String TreeHeight;
	    protected String TreeSize;
	    protected String adress_street_num;
	    protected String adress_street;
	    protected String adress_city;
	    protected String adress_state;
	    protected String adress_zip_code;
	    protected String ProxToHouse;
	    protected String RequestNote;

	 
	    //constructors
	    public TreeRequest() {
	    }
	 
	    public TreeRequest(String RequestID) 
	    {
	        this.RequestID = RequestID;
	    }
	    
	    
	    /*public users(String RequestID,String ClientID, String TreeHeight, String TreeSize, String adress_street_num, String adress_street, String adress_city, String adress_state,String adress_zip_code, String ProxToHouse, String RequestStatus, String RequestNote) 
	    {
	    	this(ClientID,TreeHeight,TreeSize, adress_street_num,  adress_street,  adress_city,  adress_state,  adress_zip_code,ProxToHouse, RequestStatus, RequestNote);
	    	this.RequestID = RequestID;
	    }*/
	 
	
	    public TreeRequest( String RequestID, String ClientID, String TreeHeight, String TreeSize, String adress_street_num, String adress_street, String adress_city, String adress_state,String adress_zip_code, String ProxToHouse, String RequestNote) 
	    {
	    	this.RequestID = RequestID;
	    	this.ClientID = ClientID;
	    	this.TreeHeight = TreeHeight;
	    	this.TreeSize = TreeSize;
	        this.adress_street_num = adress_street_num;
	        this.adress_street = adress_street;
	        this.adress_city= adress_city;
	        this.adress_state = adress_state;
	        this.adress_zip_code = adress_zip_code;
	        this.ProxToHouse = ProxToHouse;
	        this.RequestNote = RequestNote;
	    }
	    
	   //getter and setter methods
	    public String getRequestID() {
	        return RequestID;
	    }
	    public void setRequestID(String RequestID) {
	        this.RequestID = RequestID;
	    }
	    
	    public String getClientID() {
	        return ClientID;
	    }
	    public void setClientID(String ClientID) {
	        this.ClientID = ClientID;
	    }
	    
	    public String getTreeHeight() {
	        return TreeHeight;
	    }
	    public void setTreeHeight(String TreeHeight) {
	        this.TreeHeight = TreeHeight;
	    }
	    
	    public String getTreeSize() {
	        return TreeSize;
	    }
	    public void setTreeSize(String TreeSize) {
	        this.TreeSize = TreeSize;
	    }
	  
	  
	    public void setProxToHouse(String ProxToHouse) {
	    	this.ProxToHouse = ProxToHouse;
	    }
	    public String getProxToHouse() {
	        return ProxToHouse;
	    }
	    
	    public void setRequestNote(String RequestNote) {
	    	this.RequestNote = RequestNote;
	    }
	    public String getRequestNote() {
	        return RequestNote;
	    }

	    
	    
	    public String getAdress_street_num() {
	        return adress_street_num;
	    }
	    public void setAdress_street_num(String adress_street_num) {
	        this.adress_street_num = adress_street_num;
	    }
	    public String getAdress_street() {
	        return adress_street;
	    }
	    public void setAdress_street(String adress_street) {
	        this.adress_street = adress_street;
	    }
	    public String getAdress_city() {
	        return adress_city;
	    }
	    public void setAdress_city(String adress_city) {
	        this.adress_city = adress_city;
	    }
	    public String getAdress_state() {
	        return adress_state;
	    }
	    public void setAdress_state(String adress_state) {
	        this.adress_state = adress_state;
	    }
	    public String getAdress_zip_code() {
	        return adress_zip_code;
	    }
	    public void setAdress_zip_code(String adress_zip_code) {
	        this.adress_zip_code = adress_zip_code;
	    }
	    

	}