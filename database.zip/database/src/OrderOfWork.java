public class OrderOfWork 
{
		protected String ClientID;
	 	protected String OrderStatus;
	    protected String RequestNote;
	  

	 
	    //constructors
	    public OrderOfWork() {
	    }
	 
	    public OrderOfWork(String ClientID) 
	    {
	        this.ClientID = ClientID;
	    }
	    
	    /*public users(String ClientID,String RequestStatus, String InitialQuote, String RequestNote, String adress_street_num, String adress_street, String adress_city, String adress_state,String adress_zip_code, String ProxToHouse, String RequestStatus, String RequestNote) 
	    {
	    	this(RequestStatus,InitialQuote,RequestNote, adress_street_num,  adress_street,  adress_city,  adress_state,  adress_zip_code,ProxToHouse, RequestStatus, RequestNote);
	    	this.ClientID = ClientID;
	    }*/
	 
	
	    public OrderOfWork( String ClientID, String OrderStatus, String RequestNote) 
	    {
	    	this.ClientID = ClientID;
	    	this.OrderStatus = OrderStatus;
	    	//this.InitialQuote = InitialQuote;
	    	this.RequestNote = RequestNote;
	        
	    }
	    
	   //getter and setter methods
	    public String getClientID() {
	        return ClientID;
	    }
	    public void setClientID(String ClientID) {
	        this.ClientID = ClientID;
	    }
	    
	    public String getOrderStatus() {
	        return OrderStatus;
	    }
	    public void setOrderStatus(String OrderStatus) {
	        this.OrderStatus = OrderStatus;
	    }
	    
	   
	    
	    public String getRequestNote() {
	        return RequestNote;
	    }
	    public void setRequestNote(String RequestNote) {
	        this.RequestNote = RequestNote;
	    }
	  
}
	  
	   