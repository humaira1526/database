import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
 
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.PreparedStatement;


public class ControlServlet extends HttpServlet {
	    private static final long serialVersionUID = 1L;
	    private userDAO userDAO = new userDAO();
	    private TreeRequestDAO TreeRequestDAO = new TreeRequestDAO();
	    private ResponseToRequestDAO ResponseToRequestDAO = new ResponseToRequestDAO();
	    private OrderOfWorkDAO OrderOfWorkDAO = new OrderOfWorkDAO();
	    private ResponseToQuoteDAO ResponseToQuoteDAO = new ResponseToQuoteDAO();
	    private String currentUser;
	    private HttpSession session=null;
	    
	    public ControlServlet()
	    {
	    	
	    	
	    	
	    }
	    
	    public void init()
	    {
	    	userDAO = new userDAO();
	    	
	    	TreeRequestDAO = new TreeRequestDAO();
	    	
	    	ResponseToRequestDAO = new ResponseToRequestDAO();
	    	
	    	OrderOfWorkDAO = new OrderOfWorkDAO();
	    	
	    	ResponseToQuoteDAO = new ResponseToQuoteDAO();
	    	currentUser = "";
	    	
	    }
	    
	    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	        doGet(request, response);
	    }
	    
	    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	        String action = request.getServletPath();
	        System.out.println(action);
	    
	    try {
        	switch(action) {  
        	case "/login":
        		login(request,response);
        		break;
        		
        	case "/TreeRequest":
        		TreeRequest(request, response);
        		break;
        		
        	case "/register":
        		register(request, response);
        		break;
        		
       
        	case "/initialize":
        		userDAO.init();
        		TreeRequestDAO.init();
        		System.out.println("Database successfully initialized!");
        		rootPage(request,response,"");
        		break;
        	case "/root": 
        		rootPage(request,response, "");
        		//treeListRoot(request,response,"");
        		break;
        	case "/logout":
        		logout(request,response);
        		break;
        	 case "/list": 
                 System.out.println("The action is: list");
                 listUser(request, response);
                 
                 ListRequests(request,response);
                 break;
	    	}
	    }
	    catch(Exception ex) {
        	System.out.println(ex.getMessage());
	    	}
	    }
        	
	    private void listUser(HttpServletRequest request, HttpServletResponse response)
	            throws SQLException, IOException, ServletException {
	        System.out.println("listUser started: 00000000000000000000000000000000000");

	     
	        List<user> listUser = userDAO.listAllUsers();
	        request.setAttribute("listUser", listUser);       
	        RequestDispatcher dispatcher = request.getRequestDispatcher("UserList.jsp");       
	        
	   
	        dispatcher.forward(request, response);
	     
	        System.out.println("listPeople finished: 111111111111111111111111111111111111");
	    }
	    
	    
	    private void ListRequests(HttpServletRequest request, HttpServletResponse response)
	            throws SQLException, IOException, ServletException {
	        System.out.println("ListRequests started: 00000000000000000000000000000000000");

	     
	        List<TreeRequest> ListRequests = TreeRequestDAO.listAllRequests();
	        request.setAttribute("ListRequests", ListRequests);       
	        RequestDispatcher dispatcher = request.getRequestDispatcher("treeListRoot.jsp");       
	        dispatcher.forward(request, response);
	     
	        System.out.println("listPeople finished: 111111111111111111111111111111111111");
	    }
	    
	    
	    	        
	   private void rootPage(HttpServletRequest request, HttpServletResponse response, String view) throws ServletException, IOException, SQLException{
	    	System.out.println("root view");
			request.setAttribute("listUser", userDAO.listAllUsers());
	    	//request.getRequestDispatcher("rootView.jsp").forward(request, response);
	    	
	    	request.setAttribute("ListRequests", TreeRequestDAO.listAllRequests());
	    	request.getRequestDispatcher("rootView.jsp").forward(request, response);
	   }
	    	
	   
	   
	  /**  	
	    	private void rootPage(HttpServletRequest request, HttpServletResponse response, String view) throws ServletException, IOException, SQLException {
	    	    // Fetch data from the user table
	    	    List<user> userList = userDAO.listAllUsers();
	    	    request.setAttribute("listUser", userList);

	    	    // Fetch data from the TreeRequest table
	    	    List<TreeRequest> treeRequestList = TreeRequestDAO.listAllRequests();
	    	    request.setAttribute("ListRequests", treeRequestList);

	    	    // Forward the request to the rootView.jsp
	    	    request.getRequestDispatcher("rootView.jsp").forward(request, response);
	    	}

	    	
	    
	    
	  
	    private void treeListRoot(HttpServletRequest request, HttpServletResponse response, String view) throws ServletException, IOException, SQLException{
	    	System.out.println(" Tree root view");
			request.setAttribute("ListRequests", TreeRequestDAO.listAllRequests());
	    	request.getRequestDispatcher("treeListRoot.jsp").forward(request, response);
	    }
	     **/
	    
	    private void DavidSmith(HttpServletRequest request, HttpServletResponse response, String view) throws ServletException, IOException, SQLException{
	    	System.out.println("Page for David Smith");
			request.setAttribute("listUser", userDAO.listAllUsers());
	    	request.getRequestDispatcher("DavidSmith.jsp").forward(request, response);
	    }
	    
	    
	    protected void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {
	    	 String ClientID = request.getParameter("ClientID");
	    	 String password = request.getParameter("password");
	    	 
	    	 if (ClientID.equals("root") && password.equals("pass1234")) {
				 System.out.println("Login Successful! Redirecting to root");
				 session = request.getSession();
				 session.setAttribute("username", ClientID);
				 rootPage(request, response, "");
	    	 }
	    	 
	    	 else if (ClientID.equals("David Smith")&& password.equals("Dav1234")) {
	    		 System.out.println("Login Successful! Redirecting to David Smith's main page");
				 session = request.getSession();
				 session.setAttribute("username", ClientID);
				 DavidSmith(request, response, "");
	    	 }
	    	 
	    	 
	    	 
	    	 else if(userDAO.isValid(ClientID, password)) 
	    	 {
			 	 
			 	 currentUser = ClientID;
				 System.out.println("Login Successful! Redirecting");
				 request.getRequestDispatcher("activitypage.jsp").forward(request, response);
			 			 			 			 
	    	 }
	    	 else {
	    		 request.setAttribute("loginStr","Login Failed: Please check your credentials.");
	    		 request.getRequestDispatcher("login.jsp").forward(request, response);
	    	 }
	    }
	           
	    private void register(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {
	    	String ClientID = request.getParameter("ClientID");
	   	 	String firstName = request.getParameter("firstName");
	   	 	String lastName = request.getParameter("lastName");
	   	 	String password = request.getParameter("password");
	   	 	String adress_street_num = request.getParameter("adress_street_num"); 
	   	 	String adress_street = request.getParameter("adress_street"); 
	   	 	String adress_city = request.getParameter("adress_city"); 
	   	 	String adress_state = request.getParameter("adress_state"); 
	   	 	String adress_zip_code = request.getParameter("adress_zip_code"); 	   	 	
	   	 	String confirm = request.getParameter("confirmation");
	   	 	
	   	 	String credit_card = request.getParameter("credit_card");
	   	 	String credit_card2 = request.getParameter("credit_card2");
	   	 	String _role = request.getParameter("_role");
	   	 	if (_role.equals("David Smith")) {
	   	 		System.out.println("Please register as client");
	   	 		request.setAttribute("errorOne","Registration failed: Username taken, please enter a new username.");
	   	 		request.getRequestDispatcher("register.jsp").forward(request, response);
	   	 	}
	   	 	else if (_role.equals("Admin Root")) {
	   	 		System.out.println("Please register as client");
	   	 		request.setAttribute("errorOne","Registration failed: Username taken, please enter a new username.");
	   	 		request.getRequestDispatcher("register.jsp").forward(request, response);
	   	 	}
	   	 	else {
	   	 	if (password.equals(confirm)) {
	   	 		if (!userDAO.checkEmail(ClientID)) {
		   	 		System.out.println("Registration Successful! Added to database");
		            user users = new user(ClientID,firstName, lastName, password, adress_street_num,  adress_street,  adress_city,  adress_state,  adress_zip_code, _role, credit_card, credit_card2);
		   	 		userDAO.insert(users);
		   	 		System.out.println("It is executing insert function in userDAO");
		   	 		response.sendRedirect("login.jsp");
	   	 		}
		   	 	else {
		   	 		System.out.println("Username taken, please enter new username");
		    		 request.setAttribute("errorOne","Registration failed: Username taken, please enter a new username.");
		    		 request.getRequestDispatcher("register.jsp").forward(request, response);
		   	 	}
	   	 	}
	   	
	   	 	else {
	   	 		System.out.println("Password and Password Confirmation do not match");
	   		 request.setAttribute("errorTwo","Registration failed: Password and Password Confirmation do not match.");
	   		 request.getRequestDispatcher("register.jsp").forward(request, response);
	   	 	}
	   	 	}
	    }    
	    
	    
	    
	    private void TreeRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {
	    	String RequestID = request.getParameter("RequestID");
	   	 	String ClientID = request.getParameter("ClientID");
	   	 	String TreeHeight = request.getParameter("TreeHeight");
	   	 	String TreeSize = request.getParameter("TreeSize");
	   	 	String adress_street_num = request.getParameter("adress_street_num"); 
	   	 	String adress_street = request.getParameter("adress_street"); 
	   	 	String adress_city = request.getParameter("adress_city"); 
	   	 	String adress_state = request.getParameter("adress_state"); 
	   	 	String adress_zip_code = request.getParameter("adress_zip_code"); 	   	 	
	   	 	String confirm = request.getParameter("confirmation");
	   	 	
	   	 	String RequestNote = request.getParameter("RequestNote");
	   	 	String ProxToHouse = request.getParameter("ProxToHouse");
	   	 	
	   	 	
	   	 
	   	 		
		   	 		System.out.println("Confirmation Successful!");
		            TreeRequest TreeRequest = new TreeRequest(RequestID,ClientID, TreeHeight, TreeSize, adress_street_num,  adress_street,  adress_city,  adress_state,  adress_zip_code, ProxToHouse, RequestNote);
		   	 		TreeRequestDAO.insert(TreeRequest);
		   	 		
	   	 		
	    }
	    
	    
	    
	    
	    
	    private void ResponseToRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {
	    	String ClientID = request.getParameter("ClientID");
	   	 	String RequestStatus = request.getParameter("RequestStatus");
	   	 	String InitialQuote = request.getParameter("InitialQuote");
	   	 	String RequestNote = request.getParameter("RequestNote");
	   	 	String confirm = request.getParameter("confirmation");

	   	 		
		   	 		System.out.println("Response sent Successfully!");
		   	 	ResponseToRequest ResponseToRequest = new ResponseToRequest(ClientID,RequestStatus, InitialQuote, RequestNote);
		   	 ResponseToRequestDAO.insert(ResponseToRequest);
		   	 		
	   	 		
	    }
	    
	    
	    
	    
	    private void OrderOfWork(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {
	    	String ClientID = request.getParameter("ClientID");
	   	 	String OrderStatus = request.getParameter("OrderStatus");
	   	 	//String InitialQuote = request.getParameter("InitialQuote");
	   	 	String RequestNote = request.getParameter("RequestNote");
	   	 	String confirm = request.getParameter("confirmation");

	   	 		
		   	 		System.out.println("Response sent Successfully!");
		   	 	OrderOfWork OrderOfWork = new OrderOfWork(ClientID,OrderStatus, RequestNote);
		   	 OrderOfWorkDAO.insert(OrderOfWork);
		   	 		
	   	 		
	    }
	    
	    
	    private void ResponseToQuote(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {
	    	String ClientID = request.getParameter("ClientID");
	   	 	String OrderID = request.getParameter("OrderID");
	   	 	String RequestStatus = request.getParameter("RequestStatus");
	   	 	String RequestNote = request.getParameter("RequestNote");
	   	 	String confirm = request.getParameter("confirmation");

	   	 		
		   	 		System.out.println("Response sent Successfully!");
		   	 	ResponseToQuote ResponseToQuote = new ResponseToQuote(ClientID,OrderID, RequestStatus, RequestNote);
		   	 ResponseToQuoteDAO.insert(ResponseToQuote);
		   	 		
	   	 		
	    }
	    
	    
	   	 	
	    private void logout(HttpServletRequest request, HttpServletResponse response) throws IOException {
	    	currentUser = "";
        		response.sendRedirect("login.jsp");
        	}  
	    
}
	        
	        
	    
	        
	        
	        
	    

