import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.PreparedStatement;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
import java.sql.ResultSet;
//import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
/**
 * Servlet implementation class Connect
 */
@WebServlet("/OrderOfWorkDAO")
public class OrderOfWorkDAO 
{
	private static final long serialVersionUID = 1L;
	private Connection connect = null;
	private Statement statement = null;
	private PreparedStatement preparedStatement = null;
	private ResultSet resultSet = null;
	
	public OrderOfWorkDAO(){}
	
	/** 
	 * @see HttpServlet#HttpServlet()
     */
    protected void connect_func() throws SQLException {
    	//uses default connection to the database
        if (connect == null || connect.isClosed()) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                throw new SQLException(e);
            }
            connect = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/testdb?allowPublicKeyRetrieval=true&useSSL=false&user=root&password=john1234");
            System.out.println(connect);
        }
    }
    
    public boolean database_login(String email, String password) throws SQLException{
    	try {
    		connect_func("root","pass1234");
    		String sql = "select * from ResponseToRequest where ClientID = ?";
    		preparedStatement = connect.prepareStatement(sql);
    		preparedStatement.setString(1, email);
    		ResultSet rs = preparedStatement.executeQuery();
    		return rs.next();
    	}
    	catch(SQLException e) {
    		System.out.println("Wrong ID");
    		return false;
    	}
    }
	//connect to the database 
    public void connect_func(String username, String password) throws SQLException {
        if (connect == null || connect.isClosed()) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                throw new SQLException(e);
            }
            connect = (Connection) DriverManager
  			      .getConnection("jdbc:mysql://127.0.0.1:3306/userdb?"
  			          + "useSSL=false&user=" + username + "&password=" + password);
            System.out.println(connect);
        }
    }
    
    public List<OrderOfWork> listAllResponses() throws SQLException {
        List<OrderOfWork> ListOrderOfWork = new ArrayList<OrderOfWork>();        
        String sql = "SELECT * FROM ResponseToRequest";      
        connect_func();      
        statement = (Statement) connect.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);
         
        while (resultSet.next()) {
            String ClientID = resultSet.getString("ClientID");
            String OrderStatus = resultSet.getString("RequestStatus");
            //String InitialQuote = resultSet.getString("InitialQuote");
            String RequestNote = resultSet.getString("RequestNote");
            
            

             
            OrderOfWork OrderOfWork = new OrderOfWork(ClientID,OrderStatus, RequestNote );
            ListOrderOfWork.add(OrderOfWork);
        }        
        resultSet.close();
        disconnect();        
        return ListOrderOfWork;
    }
    
    protected void disconnect() throws SQLException {
        if (connect != null && !connect.isClosed()) {
        	connect.close();
        }
    }
    
    public void insert(OrderOfWork OrderOfWork) throws SQLException {
    	connect_func("root","pass1234");         
		String sql = "insert into ResponseToRequest(ClientID, OrderStatus, RequestNote) values (?,?,?)";
		preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
			preparedStatement.setString(1, OrderOfWork.getClientID());
			preparedStatement.setString(2, OrderOfWork.getOrderStatus());
			//preparedStatement.setString(3, ResponseToRequest.getInitialQuote());
			preparedStatement.setString(4, OrderOfWork.getRequestNote());
			
			

					

		preparedStatement.executeUpdate();
		
        preparedStatement.close();
        
    }
    
    public boolean delete(String ClientID) throws SQLException {
        String sql = "DELETE FROM ResponseToRequest WHERE ClientID = ?";        
        connect_func();
         
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, ClientID);
         
        boolean rowDeleted = preparedStatement.executeUpdate() > 0;
        preparedStatement.close();
        return rowDeleted;     
    }
     
    public boolean update(OrderOfWork OrderOfWork) throws SQLException {
        String sql = "update OrderOfWork set ClientID=?, OrderStatus =?,RequestNote=?";
        connect_func();
        
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, OrderOfWork.getClientID());
		preparedStatement.setString(2, OrderOfWork.getOrderStatus());
		//preparedStatement.setString(3, ResponseToRequest.getInitialQuote());
		preparedStatement.setString(4, OrderOfWork.getRequestNote());
		

         
        boolean rowUpdated = preparedStatement.executeUpdate() > 0;
        preparedStatement.close();
        return rowUpdated;     
    }
    
    public OrderOfWork getOrderOfWork(String ClientID) throws SQLException {
    	OrderOfWork OrderOfWork = null;
        String sql = "SELECT * FROM OrderOfWork WHERE ClientID = ?";
         
        connect_func();
         
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, ClientID);
         
        ResultSet resultSet = preparedStatement.executeQuery();
         
        if (resultSet.next()) {
        	//String ClientID = resultSet.getString("ClientID");
            //String ClientID = resultSet.getString("ClientID");
            String OrderStatus = resultSet.getString("OrderStatus");
            //String InitialQuote = resultSet.getString("InitialQuote");
            String RequestNote = resultSet.getString("RequestNote");
           
            OrderOfWork = new OrderOfWork(ClientID, OrderStatus, RequestNote);
        }
         
        resultSet.close();
        statement.close();
         
        return OrderOfWork;
    }
    
    public boolean checkRequestID(String ClientID) throws SQLException {
    	boolean checks = false;
    	String sql = "SELECT * FROM ResponseToRequest WHERE ClientID = ?";
    	connect_func();
    	preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, ClientID);
        ResultSet resultSet = preparedStatement.executeQuery();
        
        System.out.println(checks);	
        
        if (resultSet.next()) {
        	checks = true;
        }
        
        System.out.println(checks);
    	return checks;
    }
    
    public boolean checkClientID(String ClientID) throws SQLException {
    	boolean checks = false;
    	String sql = "SELECT * FROM OrderOfWork WHERE ClientID = ?";
    	connect_func();
    	preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, ClientID);
        ResultSet resultSet = preparedStatement.executeQuery();
        
        System.out.println(checks);	
        
        if (resultSet.next()) {
        	checks = true;
        }
        
        System.out.println(checks);
       	return checks;
    }
    
    
    
    public boolean isValid(String email, String password) throws SQLException
    {
    	String sql = "SELECT * FROM ResponseToRequest";
    	connect_func();
    	statement = (Statement) connect.createStatement();
    	ResultSet resultSet = statement.executeQuery(sql);
    	
    	resultSet.last();
    	
    	int setSize = resultSet.getRow();
    	resultSet.beforeFirst();
    	
    	for(int i = 0; i < setSize; i++)
    	{
    		resultSet.next();
    		if(resultSet.getString("email").equals(email) && resultSet.getString("password").equals(password)) {
    			return true;
    		}		
    	}
    	return false;
    }
    
    
    public void init() throws SQLException, FileNotFoundException, IOException{
    	connect_func();
        statement =  (Statement) connect.createStatement();
        
        String[] INITIAL = {"drop database if exists testdb; ",
					        "create database testdb; ",
					        "use testdb; ",
					        "drop table if exists ResponseToRequest; ",
					        ("CREATE TABLE if not exists ResponseToRequest( " +
					            "ClientID VARCHAR(50) NOT NULL, " + 
					            "ClientID VARCHAR(10) NOT NULL, " +
					            "TreeHeight VARCHAR(10) NOT NULL, " +
					            "TreeSize VARCHAR(20) NOT NULL, " +
					            "adress_street_num VARCHAR(4) , "+ 
					            "adress_street VARCHAR(30) , "+ 
					            "adress_city VARCHAR(20)," + 
					            "adress_state VARCHAR(2),"+ 
					            "adress_zip_code VARCHAR(5),"+ 
					            "ProxToHouse DATE NOT NULL, " +
					            "RequestStatus VARCHAR(16),"+ 
					            "RequestNote VARCHAR(16),"+
					            "PRIMARY KEY (ClientID) "+"); ")
        					};
        String[] TUPLES = {("insert into ResponseToRequest(ClientID, ClientID, TreeHeight,   TreeSize  )"+
    			"values (('0001', 'susie@gmail.com', '50', '34', '1234', 'Brush', 'Detroit', 'MI', '48001', '34', 'Need it cut ASAP', 'Yes'),"+
		    	 	 	"('0002', 'don@gmail.com', '68', '23', '1000', 'Justin', 'Troy', 'MI', '48002', '45', 'When is the earliest date?', 'Yes'),"+
		    		 	" ('0003', 'margarita@gmail.com', '56', '12', '1234', 'Ivan', 'Warren', 'MI', '48003', '23', 'Are services available on weekends?', 'No'),"+
		    		 	" ('0004', 'Mohima@gmail.com', '58', '45', '3214', 'Marko', 'AnnArbor', 'MI', '48004', '15', 'cut it soon', 'Yes'),"+
		    		 	
		    		 	" ('0005', 'moemoney@gmail.com', '23', '34', '3454', 'Polo', 'Lansing', 'MI', '48005', '33', 'Need it completed before winter', 'Pending');")
		    		 	
        };
        
        
        
        
       

        
        
        
        
  
        
        
        

		
        
       
        /*
         * {("insert into ResponseToRequest(ClientID, ClientID, TreeHeight,   TreeSize,         adress_street_num, adress_street,     adress_city,    adress_state,   adress_zip_code, RequestNote,      RequestStatus,         ProxToHouse)"+
        			"values         ('sus@gmail.com',      'Susie ',  'Guzman',   'susie1234',     '1234',             'whatever street', 'detroit',      'MI',           '48202',         '586-276-3478',  '4628562827570000', 'Client'),"+
			    	 	 	"        ('do@gmail.com',       'Don',     'Cummings', 'don123',        '1000',             'hi street',       'mama',         'MO',           '12345',         '465-465-3645',  '3527482648726748', 'Client'),"+
			    		 	"        ('margarita@gmail.com', 'Margarita','Lawson',  'margarita1234', '1234',             'ivan street',     'tata',         'CO',           '12561',         '465-365-2764',  '4637574738475778', 'Client'),"+
			    		 	"        ('jo@gmail.com',        'Jo',      'Brady',    'jo1234',        '3214',             'marko street',    'brat',         'DU',           '54321',         '465-375-4758',  '4746347487574848', 'Client'),"+
			    		 	"        ('wallace@gmail.com',   'Wallace', 'Moore',    'wallace1234',   '4500',             'frey street',     'sestra',       'MI',           '48202',         '465-476-4728',  '4855858484483399', 'Client'),"+
			    			"        ('root',                'default',  'default', 'pass1234',      '0000',             'Default',         'Default',      '0',            '00000',         '578-573-5739',  '4739573928750000', 'Admin Root'),"+
			    			"    ('David Smith',         'Main',      'Main',    'Dav1234',      '1234',             'Main',            'Main',         '0',            '12345',         '462-465-3756',  '2647285634823945', 'David Smith');")

        };*/
         
        
       
        
        
        
        
        
        
        
        
        
        //for loop to put these in database
        for (int i = 0; i < INITIAL.length; i++)
        	statement.execute(INITIAL[i]);
        for (int i = 0; i < TUPLES.length; i++)	
        	statement.execute(TUPLES[i]);
        disconnect();
    }
    
    
   
    
    
    
    
    
	
	

}